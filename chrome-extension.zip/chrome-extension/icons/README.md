# Extension Icons

Place your extension icons here:

- `icon16.png` - 16x16 pixels (toolbar)
- `icon48.png` - 48x48 pixels (extension management)
- `icon128.png` - 128x128 pixels (Chrome Web Store)

For now, you can use placeholder images or generate icons from your logo.
